The http reuests to be used are:

all-tweets: returns all tweets in the form ID: ###, Text: ssss. Can be triggered by clicking button that says "Get all tweets."
all-users: returns all users in the form ID: ###, Name: nnnn. Can be triggered by clicking button that says "Get all users."
links: returns all links mentioned in all tweets, in their external link form. Can be triggered by clicking button that says "Get all external links."
tweet/id=###: returns all the features of the specified link in the form key: value. Can be triggered by clicking button that says "Get tweet info" after typing a correct ID in the input box beside it.
user/id=###: returns all the features of the specified user in the form key: value. Can be triggered by clicking button that says "Get user info" after typing a correct ID in the input box beside it.
user-popularity: returns the most popular user, based on number of followers, in the form "nnnn is the most popular user with #### followers." Can be triggered by clicking the button that says "Find most popular user."